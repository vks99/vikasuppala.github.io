function Submit(){

    var fname = document.getElementById("fname").value;
    var email = document.getElementById("email").value;
    var issues = document.getElementById("issues").value;
    var servtype = document.getElementById("servtype").value;
    var rate = document.getElementsByName("rate");
    var info = document.getElementsByName("info");
    var infoneed = document.getElementById("infoneed").value;
    var recom = document.getElementsByName("recom");
    var errorfname = document.getElementById("errorfname");
    var erroremail = document.getElementById("erroremail");
    var errorservtype = document.getElementById("errorservtype");
    var errorissues = document.getElementById("errorissues");
    var errorrate = document.getElementById("errorrate");
    var errorinfo = document.getElementById("errorinfo");
    var errorinfoneed = document.getElementById("errorinfoneed");
    var errorrecom = document.getElementById("errorrecom");
    var text = " ";
    var rateValue = false;
    var infoValue = false;
   
    if(fname == "")
    {
        text = "Please Enter Full Name";
        errorfname.innerHTML = text;        
    }
    if(email.indexOf("@") == -1)
    {
        text = "Please Enter Valid EmailId";
        erroremail.innerHTML = text; 
    }
    if(servtype == "None")
    {
        text = "Please Select Service Type";
        errorservtype.innerHTML = text;
    }
    if(issues == "" || issues.length < 100)
    {
        text = "Please Enter the data more than 50 characters ";
        errorissues.innerHTML = text;
      
    }
    for(var i=0; i<rate.length;i++){
        if(rate[i].checked == true){
            rateValue = true;    
        }
    }
    if(!rateValue){
        text = "Please rate our service";
        errorrate.innerHTML=text;
    }
    for(var i=0; i<info.length;i++){
        if(info[i].checked == true){
            infoValue = true;    
        }
    }
    if(!infoValue){
        text = "Please select any option";
        errorinfo.innerHTML=text;
    }
    if(infoneed == "None")
    {
        text = "Please select any option";
        errorinfoneed.innerHTML = text;
    }
    if(recom.checked == false)
    {
        text = "Please select any option";
        errorrecom.innerHTML = text;
    }
    if(text == " " && rateValue==true && infoValue==true)
    {
        alert("Form Submited Sucessfully");
    }
    else{
        document.getElementById("submitId").style.backgroundColor = "red";
        document.getElementById("submitId").style.color = "white";
        return false;
    }
}