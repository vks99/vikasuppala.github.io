var images = [];
var time = 1000;
var i=0;
images[0] = 'Image7.jpg';
images[1] = 'Image5.jpg';
images[2] = 'Image10.jpg';

function scrollImg(){

    document.slide.src = images[i];

    if(i < images.length -1){
        i++;
    }else
    {
        i=0;
    }

    setTimeout("scrollImg()", time);

}

window.onload = scrollImg;