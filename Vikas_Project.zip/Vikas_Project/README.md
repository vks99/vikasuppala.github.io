## Lab7
## Name : Vikas Uppala
## Student Number : N01486527

## Tasks
[x] Created a Home Page adding Image sliding feature using JavaScript